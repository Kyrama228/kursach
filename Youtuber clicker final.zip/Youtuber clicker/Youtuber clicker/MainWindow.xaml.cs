﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Youtuber_clicker.GameControllers;
using Youtuber_clicker.Systema;
using Youtuber_clicker.View;


namespace Youtuber_clicker
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // отправка изменений
        private void SendViewData(MyView v)
        {
            v.AddLabel(ScoreLabel);
            v.AddSpeedOfAddingPointsLabel(SpeedOfAddingPointsLabel);
            v.AddClickPointAddLabel(ClickPointAddLabel);
            // апгрейд
            v.AddButtons(Improvement1Button, Improvement2Button, Improvement3Button, Improvement4Button, Improvement5Button, Improvement6Button);
            v.AddImprovementsLevelsLabels(Improvement1Label, Improvement2Label, Improvement3Label, Improvement4Label, Improvement5Label, Improvement6Label, DoubleClickerLabel, DoublePointerLabel);
            v.AddInfoLabels(Info1Label, Info2Label, Info3Label, Info4Label, Info5Label, Info6Label);
            v.AddImprovementImages(improvement1Image, improvement2Image, improvement3Image, improvement4Image, improvement5Image, improvement6Image);
            v.SetButtonsTexts(controller.BasicImprovements[0].StartingPrice,
                controller.BasicImprovements[1].StartingPrice,
                controller.BasicImprovements[2].StartingPrice,
                controller.BasicImprovements[3].StartingPrice,
                controller.BasicImprovements[4].StartingPrice,
                controller.BasicImprovements[5].StartingPrice);
            // double clicker + double pointer
            v.AddButtons(BonusImprovement1Button);
            v.AddButtons(BonusImprovement2Button);
        }
        ProgramData models = new ProgramData();
        MyView view = new MyView(); 
        UserController controller = new UserController(); 
        public MainWindow()
        {
            InitializeComponent();
            models.SendData(controller, view);
            SendViewData(view);
            controller.UploadSavedData();
        }
        //кнопка кликер
        private void YouTubeButton_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();
            controller.ClickButton();
            ClickPointAddLabel.Margin = new Thickness(rnd.Next(0, 150), rnd.Next(0, 150), rnd.Next(0, 150), rnd.Next(0, 150));
        }
        private void ClickPointAddLabel_Click(object sender, RoutedEventArgs e)
        {
            controller.ClickButton();
        }
        // Improvements
        private void Improvement1Button_Click(object sender, RoutedEventArgs e)
        {
            controller.ClickBasicImprovement(0);
        }

        private void Improvement2Button_Click(object sender, RoutedEventArgs e)
        {
            controller.ClickBasicImprovement(1);
        }

        private void Improvement3Button_Click(object sender, RoutedEventArgs e)
        {
            controller.ClickBasicImprovement(2);
        }

        private void Improvement4Button_Click(object sender, RoutedEventArgs e)
        {

            controller.ClickBasicImprovement(3);
        }

        private void Improvement5Button_Click(object sender, RoutedEventArgs e)
        {
            controller.ClickBasicImprovement(4);
        }

        private void Improvement6Button_Click(object sender, RoutedEventArgs e)
        {          
            fm.NavigationService.Navigate(new EndGame());
            gr1.Visibility = Visibility.Hidden;            
        }
        private void BonusImprovement1Button_Click(object sender, RoutedEventArgs e)
        {
            controller.ClickDoubleClicker();
        }
        private void BonusImprovement2Button_Click(object sender, RoutedEventArgs e)
        {
            controller.ClickDoublePointer();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure", "Title_here", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                this.Close();
            }
            
        }
    }
}
