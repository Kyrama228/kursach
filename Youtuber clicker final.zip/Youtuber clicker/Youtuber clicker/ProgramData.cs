﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youtuber_clicker.GameControllers;
using Youtuber_clicker.Systema;
using Youtuber_clicker.View;

namespace Youtuber_clicker
{
    class ProgramData
    {
        User user = new User();
        BasicImprovement BI1 = new BasicImprovement(15, 0.1); 
        BasicImprovement BI2 = new BasicImprovement(100, 1); 
        BasicImprovement BI3 = new BasicImprovement(1100, 8); 
        BasicImprovement BI4 = new BasicImprovement(12000, 47); 
        BasicImprovement BI5 = new BasicImprovement(130000, 260); 
        BasicImprovement BI6 = new BasicImprovement(1400000, 1400); 
        public ProgramData()
        {

        }
        public void SendData(UserController c, MyView v)
        {
            // link
            c.LinkView(v);
            // main click
            c.AddBasicImprovements(BI1, BI2, BI3, BI4, BI5, BI6);
            //
            c.AddUser(user);
        }
    }
}
